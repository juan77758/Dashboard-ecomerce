; AutoCAD completo para Windows. No ejecutado en este entorno.
; APPLOAD, despues GUARDAR_MAESTRO_DWG.
(vl-load-com)
(defun C:GUARDAR_MAESTRO_DWG (/ f app doc output root n result)
  (setq f (findfile "BIBLIOTECA_BLOQUES_MAESTRA.dxf"))
  (if (not f) (setq f (getfiled "Selecciona BIBLIOTECA_BLOQUES_MAESTRA.dxf" "" "dxf" 0)))
  (if f
    (progn
      (setq app (vlax-get-acad-object))
      (setq result (vl-catch-all-apply 'vla-Open (list (vla-get-Documents app) f)))
      (if (vl-catch-all-error-p result)
        (princ (strcat "\nNo se pudo abrir: " (vl-catch-all-error-message result)))
        (progn
          (setq doc result root (strcat (vl-filename-directory f) "/") n 2)
          (setq output (strcat root "BIBLIOTECA_BLOQUES_MAESTRA.dwg"))
          (while (findfile output)
            (setq output (strcat root "BIBLIOTECA_BLOQUES_MAESTRA_" (itoa n) ".dwg") n (1+ n)))
          (vla-Activate doc)
          (setq result (vl-catch-all-apply 'vla-SaveAs (list doc output 64)))
          (if (vl-catch-all-error-p result)
            (princ (strcat "\nNo se pudo guardar: " (vl-catch-all-error-message result)))
            (princ (strcat "\nDWG guardado: " output)))
        )
      )
    )
    (princ "\nCancelado.")
  )
  (princ)
)
